
//  Created by Mark Obrien on 1/9/26.
//

import SwiftUI

@main
struct ArtBeforeBedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
